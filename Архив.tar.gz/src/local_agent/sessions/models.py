"""Модель сессии хранит настройки разговора независимо от HTTP и формата хранения."""

from datetime import datetime

from pydantic import BaseModel, Field

DEFAULT_SESSION_TITLE = "Новая сессия"


class Session(BaseModel):
    id: str
    title: str
    created_at: datetime
    updated_at: datetime
    agent_id: str
    model: str
    provider: str
    # Устарело: своя папка была у сессий до проектов, поле читается только из старых JSON для миграции.
    # Сервис подставляет сюда папку проекта для runtime и инструментов; не сохраняется и не уходит в API.
    workspace: str | None = Field(default=None, exclude=True)
    # Каждая сессия принадлежит проекту; None бывает только у старых записей до миграции при старте.
    project_id: str | None = None
    # Последний запрос: входные токены, размер окна модели и скорость генерации (токенов в секунду).
    context_tokens: int | None = None
    context_window: int | None = None
    tokens_per_second: float | None = None
    # Резюме сообщений, которые уже не помещаются в окно модели, и последнее из них.
    summary: str = ""
    summary_until_message_id: str | None = None
    # Ход остановлен на подтверждении: поток графа в чекпоинтах и что именно ждёт решения пользователя.
    pending_thread: str | None = None
    pending: dict | None = None
    # У дочерней сессии саб-агента — сессия, которая поручила ему работу.
    parent_id: str | None = None
    # Задача саб-агента в дочерней сессии: agent_id, agent_name, title, status (queued, running, done, failed), error.
    task: dict | None = None
    # Дочерние сессии не показываются в общем списке.
    hidden: bool = False
