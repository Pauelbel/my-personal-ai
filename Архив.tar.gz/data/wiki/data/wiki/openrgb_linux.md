# Настройка OpenRGB на Linux

**Суть:** Настройка системы для работы OpenRGB без прав sudo с поддержкой видеокарты, материнки Gigabyte (B650E AORUS ELITE X AX ICE), оперативной памяти и ARGB-кулеров.

| Действие | Команда | Пояснение/Особенности |
| --- | --- | --- |
| Разрешить запуск | `chmod +x OpenRGB.AppImage` | Дает права на выполнение AppImage из папки пользователя. |
| Загрузить модули I2C | `sudo modprobe i2c-dev` <br> `sudo modprobe i2c-piix4` | Необходимы для работы с памятью (для AMD используется `i2c-piix4`). |
| Постоянная загрузка I2C | `echo -e "i2c-dev\ni2c-piix4" \| sudo tee /etc/modules-load.d/i2c.conf` | Добавляет модули в список автозагрузки при старте системы. |
| Извлечение правил | `./OpenRGB.AppImage --appimage-extract` | Позволяет достать файл `60-openrgb.rules` из внутреннего контейнера. |
| Установка правил | `sudo cp squashfs-root/usr/lib/udev/rules.d/60-openrgb.rules /etc/udev/rules.d/` | Копирует правила в системную директорию udev. |
| Доступ I2C | `echo 'KERNEL=="i2c-[0-9]*", TAG+="uaccess"' \| sudo tee /etc/udev/rules.d/61-i2c-uaccess.rules` | Дает права на доступ к контроллерам памяти. |
| Доступ Gigabyte | Команда `printf ...` (см. ниже) | Позволяет программе видеть материнку и ARGB-кулеры (USB ID 048d:5702). |
| Применить правила | `sudo udevadm control --reload-rules` <br> `sudo udevadm trigger` | Обновляет правила udev немедленно. |
| Перенос профилей | `mkdir -p ~/.config/OpenRGB` <br> `sudo cp /root/.config/OpenRGB/*.orp ~/.config/OpenRGB/` | Переносит профили, сохраненные ранее при запуске через sudo. |

**Контекст:**
- **Оборудование:** Процессор AMD, плата GIGABYTE B650E AORUS ELITE X AX ICE.
- **Nюансы:** 
  - Запуск через sudo не рекомендуется, так как это выносит профили в `/root`.
  - Для Intel вместо `i2c-piix4` нужно использовать `i2c-i801`.
  - После применения правил проверьте права: `ls -l /dev/i2c-*` должен показывать плюс (например, `crw-rw----+`).
  - Команда для доступа к контроллеру Gigabyte (USB ID 048d:5702):
    `printf '%s\n' 'SUBSYSTEM=="hidraw", ATTRS{idVendor}=="048d", ATTRS{idProduct}=="5702", TAG+="uaccess"' 'SUBSYSTEM=="usb", ATTR{idVendor}=="048d", ATTR{idProduct}=="5702", TAG+="uaccess"' | sudo tee /etc/udev/rules.d/62-gigabyte-rgb.rules`
